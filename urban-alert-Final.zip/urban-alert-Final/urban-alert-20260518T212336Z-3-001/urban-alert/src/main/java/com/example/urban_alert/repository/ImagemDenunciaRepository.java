package com.example.urban_alert.repository;

import com.example.urban_alert.model.ImagemDenuncia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ImagemDenunciaRepository
        extends JpaRepository<ImagemDenuncia, Long> {
}