package com.example.urban_alert.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Table(name = "imagens_denuncia")
@Data
public class ImagemDenuncia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "denuncia_id")
    private Long denunciaId;

    @Column(name = "nome_arquivo")
    private String nomeArquivo;

    @Column(name = "url_imagem", columnDefinition = "TEXT")
    private String urlImagem;

    @Column(name = "data_upload")
    private LocalDateTime dataUpload = LocalDateTime.now();
}