package com.example.urban_alert.service;

import com.example.urban_alert.model.Denuncia;
import com.example.urban_alert.model.ImagemDenuncia;
import com.example.urban_alert.repository.DenunciaRepository;
import com.example.urban_alert.repository.ImagemDenunciaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DenunciaService {

    @Autowired
    private DenunciaRepository repository;

    @Autowired
    private ImagemDenunciaRepository imagemRepository;

    public Denuncia registrarDenuncia(
            Denuncia denuncia
    ) {

        Denuncia denunciaSalva =
                repository.save(denuncia);

        if (
                denuncia.getUrlFoto() != null &&
                !denuncia.getUrlFoto().isBlank()
        ) {

            ImagemDenuncia imagem =
                    new ImagemDenuncia();

            imagem.setDenunciaId(
                    denunciaSalva.getId()
            );

            imagem.setNomeArquivo(
                    denuncia.getUrlFoto()
            );

            imagem.setUrlImagem(
                    denuncia.getUrlFoto()
            );

            imagemRepository.save(
                    imagem
            );
        }

        return denunciaSalva;
    }

    public List<Denuncia> listarTodas() {
        return repository.findAll();
    }
}