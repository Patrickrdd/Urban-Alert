const inputEndereco = document.getElementById("endereco");
const sugestoes = document.getElementById("sugestoes");

const SUPABASE_URL =
    "https://akcruaktmyiqjyqnvvvs.supabase.co";

const SUPABASE_ANON_KEY =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFrY3J1YWt0bXlpcWp5cW52dnZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODAyNDM2MDMsImV4cCI6MjA5NTgxOTYwM30.8df50on9UzgBPRDjnhVNFApq0TZtMaI8ABA56qIV7fY";

window.supabaseClient =
    window.supabase.createClient(
        SUPABASE_URL,
        SUPABASE_ANON_KEY
    );

    console.log(window.supabase);
    console.log("SUPABASE OK");

/* =========================
   LIMITES DE BELO HORIZONTE
========================= */

const bhBounds = [
    [-20.060, -44.080],
    [-19.760, -43.850]
];

console.log("CRIANDO MAPA");
/* =========================
   MAPA LEAFLET
========================= */

console.log("SCRIPT CARREGADO");

const map = L.map("map", {
    maxBounds: bhBounds,
    maxBoundsViscosity: 1.0
}).setView([-19.9167, -43.9345], 13);

console.log("MAPA CRIADO");

L.tileLayer(
    "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    {
        attribution: "&copy; OpenStreetMap"
    }
).addTo(map);

let marcador = null;

let latitudeSelecionada = null;
let longitudeSelecionada = null;

/* =========================
   GEOLOCALIZAÇÃO
========================= */

if (navigator.geolocation) {

    navigator.geolocation.getCurrentPosition(

        (position) => {

            const latitude =
                position.coords.latitude;

            const longitude =
                position.coords.longitude;

            const dentroBH =
                latitude >= -20.060 &&
                latitude <= -19.760 &&
                longitude >= -44.080 &&
                longitude <= -43.850;

            if (dentroBH) {

                map.setView(
                    [latitude, longitude],
                    16
                );

                marcador =
                    L.marker(
                        [latitude, longitude]
                    )
                    .addTo(map)
                    .bindPopup(
                        "Você está aqui!"
                    )
                    .openPopup();

            }

        },

        (error) => {

            console.error(
                "Erro geolocalização:",
                error
            );

        }

    );

}

/* =========================
   AUTOCOMPLETE
========================= */

let timeout = null;

inputEndereco.addEventListener(
    "input",
    () => {

        clearTimeout(timeout);

        timeout = setTimeout(() => {

            buscarEndereco(
                inputEndereco.value
            );

        }, 500);

    }
);

async function buscarEndereco(valor) {

    if (valor.length < 3) {

        sugestoes.innerHTML = "";

        return;
    }

    try {

        const response =
            await fetch(
                `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(valor + ", Belo Horizonte")}&limit=5&countrycodes=br&bounded=1&viewbox=-44.080,-19.760,-43.850,-20.060`
            );

        const data =
            await response.json();

        sugestoes.innerHTML = "";

        if (data.length === 0) {

            sugestoes.innerHTML =
                `
                <div class="sugestao-item">
                    Nenhum endereço encontrado em Belo Horizonte
                </div>
                `;

            return;
        }

        data.forEach(local => {

            const item =
                document.createElement("div");

            item.classList.add(
                "sugestao-item"
            );

            item.innerText =
                local.display_name;

            item.addEventListener(
                "click",
                () => {

                    inputEndereco.value =
                        local.display_name;

                    sugestoes.innerHTML = "";

                    const lat =
                        parseFloat(local.lat);

                    const lon =
                        parseFloat(local.lon);

                    latitudeSelecionada =
                        lat;

                    longitudeSelecionada =
                        lon;

                    console.log(
                        "Latitude:",
                        latitudeSelecionada
                    );

                    console.log(
                        "Longitude:",
                        longitudeSelecionada
                    );

                    map.setView(
                        [lat, lon],
                        17
                    );

                    if (marcador) {

                        map.removeLayer(
                            marcador
                        );

                    }

                    marcador =
                        L.marker([lat, lon])
                        .addTo(map)
                        .bindPopup(
                            local.display_name
                        )
                        .openPopup();
                }
            );

            sugestoes.appendChild(item);

        });

    } catch (error) {

        console.error(
            "Erro API:",
            error
        );

    }

}

/* =========================
   FECHAR SUGESTÕES
========================= */

document.addEventListener(
    "click",
    (e) => {

        const autocomplete =
            document.querySelector(
                ".autocomplete"
            );

        if (
            autocomplete &&
            !autocomplete.contains(
                e.target
            )
        ) {

            sugestoes.innerHTML = "";

        }

    }
);

/* =========================
   ENVIO PARA SPRING BOOT
========================= */

const formulario =
    document.getElementById(
        "formDenuncia"
    );

if (formulario) {

    formulario.addEventListener(
    "submit",
    async (e) => {

        console.log("SUBMIT INICIADO");

        e.preventDefault();

        const tipoProblema =
            document.getElementById(
                "tipoProblema"
            ).value;

        const endereco =
            document.getElementById(
                "endereco"
            ).value;

        const descricao =
            document.getElementById(
                "descricao"
            ).value;

        const arquivo =
            document.getElementById(
                "foto"
            ).files[0];

        let urlFoto = null;
        let nomeArquivo = null;

        try {

            /* =========================
               UPLOAD PARA SUPABASE
            ========================= */

            if (arquivo) {

                nomeArquivo =
                    `denuncias/${Date.now()}_${arquivo.name}`;

                const {
                    data: uploadData,
                    error
                } =
                    await window.supabaseClient.storage
                        .from("teste")
                        .upload(
                            nomeArquivo,
                            arquivo
                        );

                if (error) {

                    console.error(
                        "Erro upload:",
                        error
                    );

                    alert(
                        "Erro ao enviar imagem."
                    );

                    return;
                }

                console.log(
                    "Upload realizado:",
                    uploadData
                );

                const { data } =
                    window.supabaseClient.storage
                        .from("teste")
                        .getPublicUrl(
                            nomeArquivo
                        );

                urlFoto =
                    data.publicUrl;

                console.log(
                    "Imagem enviada:",
                    urlFoto
                );
            }

            /* =========================
               OBJETO DA DENÚNCIA
            ========================= */

            const dadosDenuncia = {

                tipoProblema:
                    tipoProblema,

                endereco:
                    endereco,

                descricao:
                    descricao,

                latitude:
                    latitudeSelecionada,

                longitude:
                    longitudeSelecionada,

                urlFoto:
                    urlFoto
            };

            console.log(
                "Dados enviados:"
            );

            console.log(
                dadosDenuncia
            );

            /* =========================
               ENVIO PARA SPRING BOOT
            ========================= */

            const resposta =
                await fetch(
                    "http://localhost:8080/api/denuncias",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body:
                            JSON.stringify(
                                dadosDenuncia
                            )
                    }
                );

            if (resposta.ok) {

                alert(
                    "Denúncia enviada com sucesso!"
                );

                formulario.reset();

                latitudeSelecionada =
                    null;

                longitudeSelecionada =
                    null;

                if (marcador) {

                    map.removeLayer(
                        marcador
                    );
                }

            } else {

                console.error(
                    await resposta.text()
                );

                alert(
                    "Erro ao enviar denúncia."
                );
            }

        } catch (erro) {

            console.error(
                "Erro:",
                erro
            );

            alert(
                "Não foi possível conectar ao servidor."
            );
        }

    }
);
}